# Timer
 
a Bash Alert Timer.

# How To Use It

1. Download ```install.sh``` and run it ```bash install.sh``` .\
2. Check this folder ```Timer/``` in ```~/```. If you have this, let's go next. If you haven't got this, Please read the part of ```Install-Error```
3. Run ```timer``` .

# Install-Error

## 1. If You Haven't Got the folder of ```Timer/```

Please run it again.

## 2. If You Cannot Clone the Timer

Please check if you have a folder named ```Timer``` .

If you have it, you can rename it.

You haven't a foldef named ```Timer``` , please check your Internet.

